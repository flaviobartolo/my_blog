posts_data = [
  {
    'author':'anthony',
    'slug': 'lorem-ipsum',
    'title':'Lorem Ipsum',
    'text':'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Pretium lectus quam id leo in vitae turpis massa sed. Dolor magna eget est lorem. Tortor dignissim convallis aenean et tortor at risus viverra. Mattis aliquam faucibus purus in massa tempor nec feugiat nisl. Fames ac turpis egestas sed tempus urna. Condimentum mattis pellentesque id nibh tortor id. Pulvinar etiam non quam lacus suspendisse faucibus.',
  },
  {
    'author':'keith',
    'slug': 'feugiat-pretium',
    'title':'Feugiat Pretium',
    'text':'Condimentum mattis pellentesque id nibh tortor id. Pulvinar etiam non quam lacus suspendisse faucibus. Nisl nunc mi ipsum faucibus vitae aliquet nec ullamcorper sit. Rhoncus dolor purus non enim praesent elementum facilisis.',
  },
  {
    'author':'mary',
    'slug': 'habitasse-platea',
    'title':'Habitasse platea',
    'text':'Tortor at risus viverra adipiscing at in tellus integer. Et netus et malesuada fames ac turpis egestas. Aliquet eget sit amet tellus cras adipiscing enim eu.',
  },
  {
    'author':'stefanny',
    'slug': 'facilisi-nullam',
    'title':'Facilisi nullam',
    'text':'Ornare quam viverra orci sagittis eu volutpat odio facilisis.',
  },
  {
    'author':'john',
    'slug': 'arcu-dictum',
    'title':'Arcu dictum',
    'text':'Quam id leo in vitae turpis massa sed elementum.',
  },
]